package be.bloodyshine.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.view.animation.ScaleAnimation
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import java.util.Locale
import java.util.Timer
import java.util.TimerTask
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        var sessionStartTime: Long = 0L
        var glowLayout: ConstraintLayout? = null
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var tvWelcome: TextView
    private lateinit var tvNews: TextView
    private lateinit var btnConnect: ImageButton
    private lateinit var btnSettings: ImageButton
    private lateinit var progressBar: ProgressBar
    private var newsTimer: Timer? = null
    private var glowAnimator: ValueAnimator? = null
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionStartTime = System.currentTimeMillis()
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("bloodyshine_prefs", MODE_PRIVATE)

        tvWelcome = findViewById(R.id.tvWelcome)
        tvNews = findViewById(R.id.tvNews)
        btnConnect = findViewById(R.id.btnConnect)
        btnSettings = findViewById(R.id.btnSettings)
        progressBar = findViewById(R.id.progressBar)
        glowLayout = findViewById(R.id.glowLayout)

        applyLocale()
        setupGlow()
        setupAnimations()
        fetchAndShowNews()
        startNewsTimer()
    }

    override fun onResume() {
        super.onResume()
        applyLocale()
        setupGlow()
    }

    override fun onDestroy() {
        super.onDestroy()
        newsTimer?.cancel()
        glowAnimator?.cancel()
        executor.shutdownNow()
    }

    private fun applyLocale() {
        val lang = prefs.getString("language", "en") ?: "en"
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = resources.configuration
        config.setLocale(locale)
        @Suppress("DEPRECATION")
        resources.updateConfiguration(config, resources.displayMetrics)
        tvWelcome.text = getString(R.string.welcome)
    }

    private fun setupGlow() {
        val glowEnabled = prefs.getBoolean("glow_enabled", true)
        glowLayout?.let { layout ->
            if (glowEnabled) {
                layout.visibility = ConstraintLayout.VISIBLE
                startGlowAnimation(layout)
            } else {
                layout.visibility = ConstraintLayout.GONE
                glowAnimator?.cancel()
            }
        }
    }

    private fun startGlowAnimation(layout: ConstraintLayout) {
        glowAnimator?.cancel()
        val colorFrom = 0x22C0392B.toInt()
        val colorTo = 0x55E74C3C.toInt()
        glowAnimator = ValueAnimator.ofObject(ArgbEvaluator(), colorFrom, colorTo).apply {
            duration = 2000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                layout.setBackgroundColor(animator.animatedValue as Int)
            }
            start()
        }
    }

    private fun setupAnimations() {
        btnConnect.setOnClickListener {
            val rotate = RotateAnimation(
                0f, 360f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
            ).apply {
                duration = 300
                fillAfter = false
            }
            btnConnect.startAnimation(rotate)

            val scale = ScaleAnimation(
                1f, 0.9f, 1f, 0.9f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
            ).apply {
                duration = 150
                repeatMode = Animation.REVERSE
                repeatCount = 1
            }
            btnConnect.startAnimation(scale)

            Handler(Looper.getMainLooper()).postDelayed({
                startActivity(Intent(this, CheatActivity::class.java))
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }, 300)
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }

        val fadeIn = AlphaAnimation(0f, 1f).apply { duration = 250 }
        glowLayout?.startAnimation(fadeIn)
    }

    /** Fetch news from backend and display latest item */
    private fun fetchAndShowNews() {
        executor.submit {
            val items = BackendClient.getNews(limit = 5)
            runOnUiThread {
                if (items.isNotEmpty()) {
                    // Show latest news title + body
                    val latest = items.first()
                    tvNews.text = if (latest.title.isNotEmpty()) {
                        "${latest.title}\n${latest.body}"
                    } else {
                        latest.body.ifEmpty { getString(R.string.news) }
                    }
                } else {
                    tvNews.text = getString(R.string.news)
                }
            }
        }
    }

    private fun startNewsTimer() {
        newsTimer = Timer()
        newsTimer?.schedule(object : TimerTask() {
            override fun run() {
                fetchAndShowNews()
            }
        }, 10_000, 10_000)
    }
}
