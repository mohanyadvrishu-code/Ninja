package be.bloodyshine.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import be.bloodyshine.bedrockapi.PingClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.concurrent.Executors

data class ServerEntry(val ip: String, val port: Int, var motd: String = "")

class CheatActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var rvServers: RecyclerView
    private lateinit var etIp: EditText
    private lateinit var etPort: EditText
    private lateinit var btnAdd: ImageButton
    private lateinit var btnPlay: ImageButton
    private lateinit var btnStop: ImageButton
    private lateinit var btnBack: ImageButton
    private lateinit var tvSelected: TextView
    private lateinit var tvAdded: TextView

    private val servers = mutableListOf<ServerEntry>()
    private var selectedServer: ServerEntry? = null
    private val executor = Executors.newCachedThreadPool()
    private lateinit var adapter: ServerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cheat)

        prefs = getSharedPreferences("bloodyshine_prefs", MODE_PRIVATE)

        rvServers = findViewById(R.id.rvServers)
        etIp = findViewById(R.id.etIp)
        etPort = findViewById(R.id.etPort)
        btnAdd = findViewById(R.id.btnAdd)
        btnPlay = findViewById(R.id.btnPlay)
        btnStop = findViewById(R.id.btnStop)
        btnBack = findViewById(R.id.btnBack)
        tvSelected = findViewById(R.id.tvSelected)
        tvAdded = findViewById(R.id.tvAdded)

        loadServers()

        adapter = ServerAdapter(servers, this,
            onSelect = { server ->
                selectedServer = server
                RelayService.targetServer = InetSocketAddress(server.ip, server.port)
                RelayService.selectedServerName = "${server.ip}:${server.port}"
                tvSelected.text = "${getString(R.string.server_selected)}: ${server.ip}:${server.port}"
                Toast.makeText(this, getString(R.string.server_set) + ": ${server.ip}:${server.port}", Toast.LENGTH_SHORT).show()
            },
            onEdit = { server, index ->
                showEditDialog(server, index)
            },
            onRemove = { index ->
                if (index >= 0 && index < servers.size) {
                    servers.removeAt(index)
                    adapter.notifyItemRemoved(index)
                    saveServers()
                }
            }
        )

        rvServers.layoutManager = LinearLayoutManager(this)
        rvServers.adapter = adapter

        btnAdd.setOnClickListener { addServer() }

        btnPlay.setOnClickListener {
            if (selectedServer == null) {
                Toast.makeText(this, getString(R.string.server_selected), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this, RelayService::class.java)
            intent.putExtra("server_ip", selectedServer!!.ip)
            intent.putExtra("server_port", selectedServer!!.port)
            startForegroundService(intent)
            Toast.makeText(this, getString(R.string.cheat_running), Toast.LENGTH_SHORT).show()
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, RelayService::class.java))
        }

        btnBack.setOnClickListener {
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun addServer() {
        val ipRaw = etIp.text.toString().trim()
        val portRaw = etPort.text.toString().trim()

        if (ipRaw.isEmpty() || portRaw.isEmpty()) {
            showError(getString(R.string.server_error_address))
            return
        }

        val port = portRaw.toIntOrNull()
        if (port == null || port < 1 || port > 65535) {
            showError(getString(R.string.server_error_address))
            return
        }

        val duplicate = servers.any { it.ip == ipRaw && it.port == port }
        if (duplicate) {
            showError(getString(R.string.server_error_added))
            return
        }

        val server = ServerEntry(ipRaw, port, getString(R.string.server_motd_connecting))
        servers.add(server)
        adapter.notifyItemInserted(servers.size - 1)
        saveServers()

        etIp.text.clear()
        etPort.text.clear()

        // Fetch MOTD in background
        fetchMotd(server, servers.size - 1)
    }

    private fun fetchMotd(server: ServerEntry, index: Int) {
        executor.submit {
            val motd = try {
                val pong = PingClient().ping(InetSocketAddress(server.ip, server.port), 5000)
                pong?.motd ?: getString(R.string.server_motd_timeout)
            } catch (e: Exception) {
                getString(R.string.server_motd_failed_resolve)
            }
            runOnUiThread {
                if (index < servers.size) {
                    servers[index] = servers[index].copy(motd = motd)
                    adapter.notifyItemChanged(index)
                    saveServers()
                }
            }
        }
    }

    private fun showEditDialog(server: ServerEntry, index: Int) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_server, null)
        val etEditIp = view.findViewById<EditText>(R.id.etEditIp)
        val etEditPort = view.findViewById<EditText>(R.id.etEditPort)
        etEditIp.setText(server.ip)
        etEditPort.setText(server.port.toString())

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.server_details))
            .setView(view)
            .setPositiveButton(getString(R.string.server_save)) { _, _ ->
                if (index >= 0 && index < servers.size) {
                    val newIp = etEditIp.text.toString().trim()
                    val newPort = etEditPort.text.toString().toIntOrNull() ?: server.port
                    servers[index] = ServerEntry(newIp, newPort, getString(R.string.server_motd_connecting))
                    adapter.notifyItemChanged(index)
                    saveServers()
                    fetchMotd(servers[index], index)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showError(message: String) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.server_error_title))
            .setMessage(message)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private fun saveServers() {
        val arr = JSONArray()
        for (s in servers) {
            val obj = JSONObject()
            obj.put("ip", s.ip)
            obj.put("port", s.port)
            obj.put("motd", s.motd)
            arr.put(obj)
        }
        prefs.edit().putString("servers", arr.toString()).apply()
    }

    private fun loadServers() {
        val json = prefs.getString("servers", "[]") ?: "[]"
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            servers.add(
                ServerEntry(
                    obj.getString("ip"),
                    obj.getInt("port"),
                    obj.optString("motd", "")
                )
            )
        }
    }
}

class ServerAdapter(
    private val servers: MutableList<ServerEntry>,
    private val context: Context,
    private val onSelect: (ServerEntry) -> Unit,
    private val onEdit: (ServerEntry, Int) -> Unit,
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<ServerAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvIp: TextView = view.findViewById(R.id.tvServerIp)
        val tvMotd: TextView = view.findViewById(R.id.tvServerMotd)
        val btnSelect: android.widget.Button = view.findViewById(R.id.btnServerSelect)
        val btnEdit: android.widget.Button = view.findViewById(R.id.btnServerEdit)
        val btnRemove: android.widget.Button = view.findViewById(R.id.btnServerRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_server, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val server = servers[position]
        holder.tvIp.text = "${server.ip}:${server.port}"
        holder.tvMotd.text = server.motd.ifEmpty { "—" }
        holder.btnSelect.text = context.getString(R.string.server_set)
        holder.btnEdit.text = context.getString(R.string.server_edit)
        holder.btnRemove.text = context.getString(R.string.server_remove)

        holder.btnSelect.setOnClickListener {
            onSelect(server)
        }

        holder.btnEdit.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt() && pos >= 0 && pos < servers.size) {
                onEdit(servers[pos], pos)
            }
        }

        holder.btnRemove.setOnClickListener {
            // Capture the position now, before the dialog opens
            val pos = holder.bindingAdapterPosition
            if (pos < 0 || pos >= servers.size) return@setOnClickListener

            AlertDialog.Builder(context)
                .setMessage(context.getString(R.string.server_remove))
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    // Use the position captured BEFORE the dialog, not after
                    onRemove(pos)
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    override fun getItemCount() = servers.size
}
