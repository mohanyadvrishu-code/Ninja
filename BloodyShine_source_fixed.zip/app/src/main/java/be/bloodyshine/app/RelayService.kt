package be.bloodyshine.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import net.raphimc.minecraftauth.MinecraftAuth
import net.raphimc.minecraftauth.step.msa.StepMsaDeviceCode
import org.cloudburstmc.netty.channel.raknet.RakChannelFactory
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption
import org.cloudburstmc.protocol.bedrock.BedrockClientSession
import org.cloudburstmc.protocol.bedrock.BedrockPong
import org.cloudburstmc.protocol.bedrock.BedrockServerSession
import org.cloudburstmc.protocol.bedrock.codec.v589.Bedrock_v589
import org.cloudburstmc.protocol.bedrock.netty.initializer.BedrockClientInitializer
import org.cloudburstmc.protocol.bedrock.netty.initializer.BedrockServerInitializer
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacketHandler
import io.netty.bootstrap.Bootstrap
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.Channel
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.nio.NioDatagramChannel
import java.net.InetSocketAddress

class RelayService : Service() {

    companion object {
        private const val TAG = "RelayService"
        private const val CHANNEL_ID = "bloodyshine_channel"
        private const val NOTIFICATION_ID = 1

        var targetServer: InetSocketAddress = InetSocketAddress("play.hypixel.net", 19132)
        var selectedServerName: String = ""

        @Volatile
        var isRunning: Boolean = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var proxyThread: Thread? = null
    private var bossGroup: NioEventLoopGroup? = null
    private var workerGroup: NioEventLoopGroup? = null

    // Tracks the server-assigned session ID so we can end it on destroy
    private var currentSessionId: Int = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ip = intent?.getStringExtra("server_ip") ?: targetServer.hostName
        val port = intent?.getIntExtra("server_port", 19132) ?: 19132
        targetServer = InetSocketAddress(ip, port)

        startForeground(NOTIFICATION_ID, buildNotification())

        if (!isRunning) {
            isRunning = true
            proxyThread = Thread(ProxyRunnable()).also { it.start() }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false

        // Notify backend that the session ended
        val sid = currentSessionId
        val ctx = applicationContext
        Thread { BackendClient.sessionEnd(ctx, sid) }.start()

        bossGroup?.shutdownGracefully()
        workerGroup?.shutdownGracefully()
        proxyThread?.interrupt()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.cheat_running),
            NotificationManager.IMPORTANCE_LOW
        )
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.cheat_running))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    // ──────────────────────────────────────────────────────────────────────────

    private inner class ProxyRunnable : Runnable {
        override fun run() {
            try {
                runProxy()
            } catch (e: InterruptedException) {
                Log.i(TAG, "Proxy thread interrupted")
            } catch (e: Exception) {
                Log.e(TAG, "Proxy error", e)
            }
        }

        private fun runProxy() {
            // ── Step 1: Verify device with backend ────────────────────────────
            val verify = BackendClient.verify(applicationContext)

            if (!verify.isAllowed) {
                Log.w(TAG, "Backend rejected device: ${verify.status} — ${verify.message}")
                handler.post { showDisconnectDialog(verify) }
                isRunning = false
                return
            }

            // ── Step 2: Register session with backend ─────────────────────────
            val sid = BackendClient.sessionStart(
                applicationContext,
                targetServer.hostName,
                targetServer.port
            )
            currentSessionId = sid
            Log.i(TAG, "Session registered: id=$sid")

            // ── Step 3: Microsoft auth (device code flow) ─────────────────────
            val httpClient = MinecraftAuth.createHttpClient()
            val session = MinecraftAuth.BEDROCK_DEVICE_CODE_LOGIN.getFromInput(
                httpClient,
                StepMsaDeviceCode.MsaDeviceCodeCallback { deviceCode ->
                    handler.post {
                        showDeviceCodeDialog(deviceCode.directVerificationUri)
                    }
                }
            )

            if (!isRunning) return

            // ── Step 4: Start local RakNet proxy on port 19132 ────────────────
            val serverCodec = Bedrock_v589.CODEC

            bossGroup = NioEventLoopGroup(1)
            workerGroup = NioEventLoopGroup()

            val serverBootstrap = ServerBootstrap()
                .group(bossGroup, workerGroup)
                .channelFactory(RakChannelFactory.server(NioDatagramChannel::class.java))
                .option(
                    RakChannelOption.RAK_ADVERTISEMENT, BedrockPong().apply {
                        edition = "MCPE"
                        motd = "BloodyShine Proxy"
                        subMotd = "Relay"
                        playerCount = 0
                        maximumPlayerCount = 1
                        gameType = "Survival"
                        protocolVersion = serverCodec.protocolVersion
                        version = serverCodec.minecraftVersion
                        ipv4Port = 19132
                        ipv6Port = 19133
                    }
                )
                .childHandler(object : BedrockServerInitializer() {
                    override fun initSession(serverSession: BedrockServerSession) {
                        serverSession.codec = serverCodec
                        connectToRemote(serverSession, session)
                    }
                })

            val channel: Channel = serverBootstrap
                .bind(InetSocketAddress("0.0.0.0", 19132))
                .syncUninterruptibly()
                .channel()

            Log.i(TAG, "RakNet proxy bound on port 19132 → ${targetServer.hostName}:${targetServer.port}")

            // Keep-alive loop
            while (isRunning && channel.isOpen) {
                Thread.sleep(500)
            }

            channel.close().sync()
        }

        private fun connectToRemote(clientSession: BedrockServerSession, authSession: Any) {
            val codec = Bedrock_v589.CODEC
            val remoteGroup = NioEventLoopGroup()

            val bootstrap = Bootstrap()
                .group(remoteGroup)
                .channelFactory(RakChannelFactory.client(NioDatagramChannel::class.java))
                .handler(object : BedrockClientInitializer() {
                    override fun initSession(serverSession: BedrockClientSession) {
                        serverSession.codec = codec

                        // Server → Client pipe
                        serverSession.packetHandler = object : BedrockPacketHandler {
                            override fun handlePacket(packet: BedrockPacket): Boolean {
                                if (!clientSession.isClosed) {
                                    clientSession.sendPacketImmediately(packet)
                                }
                                return true
                            }
                        }

                        // Client → Server pipe
                        clientSession.packetHandler = object : BedrockPacketHandler {
                            override fun handlePacket(packet: BedrockPacket): Boolean {
                                if (!serverSession.isClosed) {
                                    serverSession.sendPacketImmediately(packet)
                                }
                                return true
                            }
                        }
                    }
                })

            bootstrap.connect(targetServer).addListener { future ->
                if (!future.isSuccess) {
                    Log.e(TAG, "Remote connect failed: ${future.cause()?.message}")
                    clientSession.disconnect(
                        "Failed to reach ${targetServer.hostName}:${targetServer.port}"
                    )
                }
            }
        }

        /** Show Microsoft device-code login dialog */
        private fun showDeviceCodeDialog(uri: String) {
            AlertDialog.Builder(this@RelayService)
                .setTitle("Xbox Login Required")
                .setMessage(
                    "Open the link below in any browser and sign in with your Microsoft account:\n\n$uri"
                )
                .setPositiveButton(android.R.string.ok, null)
                .create()
                .show()
        }

        /** Show DisconnectActivity when backend blocks this device */
        private fun showDisconnectDialog(result: VerifyResult) {
            val (titleRes, descRes) = when (result.status) {
                "banned"    -> Pair(R.string.api_disconnect_ban_title,       R.string.api_disconnect_ban_desc)
                "kicked"    -> Pair(R.string.api_disconnect_kick_title,      R.string.api_disconnect_kick_desc)
                "stop"      -> Pair(R.string.api_disconnect_stop_title,      R.string.api_disconnect_stop_desc)
                "suspected" -> Pair(R.string.api_disconnect_suspected_title, R.string.api_disconnect_suspected_desc)
                "outdated"  -> Pair(R.string.api_error_outdated_title,       R.string.api_error_outdated_desc)
                else        -> Pair(R.string.api_disconnect_unknown_title,   R.string.api_disconnect_unknown_desc)
            }

            val intent = Intent(this@RelayService, utils.DisconnectActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("title", getString(titleRes))
                putExtra("desc", result.message.ifEmpty { getString(descRes) })
                if (result.status == "outdated" && result.downloadUrl.isNotEmpty()) {
                    putExtra("download_url", result.downloadUrl)
                }
            }
            startActivity(intent)
        }
    }
}
