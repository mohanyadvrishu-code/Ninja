package be.bloodyshine.app.protocol.handler

import io.netty.channel.ChannelHandler
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import org.cloudburstmc.protocol.bedrock.BedrockSession
import android.util.Log

@ChannelHandler.Sharable
class ChExcHandler(
    private val session: BedrockSession
) : ChannelInboundHandlerAdapter() {

    companion object {
        private const val TAG = "ChExcHandler"
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        Log.e(TAG, "Channel exception caught", cause)
        if (session.downstream == null) {
            try {
                session.upstream?.disconnect()?.sync()
            } catch (e: Exception) {
                Log.e(TAG, "Error disconnecting upstream", e)
            }
        }
        ctx.close()
    }
}
