package be.bloodyshine.app.protocol.handler

import io.netty.channel.ChannelHandlerContext
import io.netty.channel.SimpleChannelInboundHandler
import org.cloudburstmc.netty.channel.raknet.packet.AcknowledgePacket
import org.cloudburstmc.protocol.bedrock.BedrockSession

class ChAckHandler(private val session: BedrockSession) :
    SimpleChannelInboundHandler<AcknowledgePacket>() {

    override fun channelRead0(ctx: ChannelHandlerContext, msg: AcknowledgePacket) {
        // Forward keepalive ACK immediately to maintain the session
        session.upstream?.writeAndFlush(AcknowledgePacket())
    }
}
