package be.bloodyshine.app

import android.content.Context
import android.provider.Settings
import android.util.Log
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Lightweight HTTP client for the BloodyShine backend.
 * All calls are blocking — run them on a background thread.
 */
object BackendClient {

    // ── Change this to your deployed domain when you publish the app ──────────
    private const val BASE_URL =
        "https://4b4a85c5-723b-4f65-8cdd-69dc620e60ac-00-2jnj0r8dbibvt.sisko.replit.dev/api"
    // ─────────────────────────────────────────────────────────────────────────

    private const val TAG = "BackendClient"
    private const val TIMEOUT_MS = 8_000

    /** Device UID — Android ID used as unique identifier */
    fun getDeviceUid(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown"

    /**
     * POST /app/verify
     *
     * Returns a [VerifyResult] indicating whether this device is allowed to use the proxy.
     * Must be called before starting the relay.
     */
    fun verify(context: Context, version: String = BuildConfig.VERSION_NAME): VerifyResult {
        return try {
            val uid = getDeviceUid(context)
            val body = JSONObject().apply {
                put("uid", uid)
                put("version", version)
            }.toString()

            val json = post("/app/verify", body)
            val status = json.optString("status", "ok")
            VerifyResult(
                status = status,
                message = json.optString("message", ""),
                latestVersion = json.optString("latestVersion", ""),
                downloadUrl = json.optString("downloadUrl", "")
            )
        } catch (e: Exception) {
            Log.w(TAG, "verify() failed — allowing offline: ${e.message}")
            VerifyResult(status = "ok", message = "")   // fail-open: don't block if server unreachable
        }
    }

    /**
     * POST /app/session/start
     * Returns the server-assigned session ID, or -1 on failure.
     */
    fun sessionStart(context: Context, serverIp: String, serverPort: Int): Int {
        return try {
            val uid = getDeviceUid(context)
            val body = JSONObject().apply {
                put("uid", uid)
                put("serverIp", serverIp)
                put("serverPort", serverPort)
            }.toString()
            val json = post("/app/session/start", body)
            json.optInt("sessionId", -1)
        } catch (e: Exception) {
            Log.w(TAG, "sessionStart() failed: ${e.message}")
            -1
        }
    }

    /**
     * POST /app/session/end
     */
    fun sessionEnd(context: Context, sessionId: Int) {
        if (sessionId < 0) return
        try {
            val uid = getDeviceUid(context)
            val body = JSONObject().apply {
                put("uid", uid)
                put("sessionId", sessionId)
            }.toString()
            post("/app/session/end", body)
        } catch (e: Exception) {
            Log.w(TAG, "sessionEnd() failed: ${e.message}")
        }
    }

    /**
     * GET /app/news
     * Returns a list of [NewsItem], newest first.
     */
    fun getNews(limit: Int = 10): List<NewsItem> {
        return try {
            val json = get("/app/news?limit=$limit")
            val arr = json.optJSONArray("items") ?: return emptyList()
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                NewsItem(
                    id = obj.optInt("id", 0),
                    title = obj.optString("title", ""),
                    body = obj.optString("body", "")
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "getNews() failed: ${e.message}")
            emptyList()
        }
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private fun post(path: String, body: String): JSONObject {
        val conn = (URL("$BASE_URL$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        OutputStreamWriter(conn.outputStream).use { it.write(body) }
        val response = conn.inputStream.bufferedReader().readText()
        return JSONObject(response)
    }

    private fun get(path: String): JSONObject {
        val conn = (URL("$BASE_URL$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            setRequestProperty("Accept", "application/json")
        }
        val response = conn.inputStream.bufferedReader().readText()
        return JSONObject(response)
    }
}

// ── Data classes ──────────────────────────────────────────────────────────────

data class VerifyResult(
    val status: String,   // "ok" | "banned" | "kicked" | "outdated" | "suspected" | "stop"
    val message: String,
    val latestVersion: String = "",
    val downloadUrl: String = ""
) {
    val isAllowed get() = status == "ok"
}

data class NewsItem(
    val id: Int,
    val title: String,
    val body: String
)
