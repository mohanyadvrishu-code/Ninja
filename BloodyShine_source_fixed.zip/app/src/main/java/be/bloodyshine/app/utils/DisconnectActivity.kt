package be.bloodyshine.app.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import be.bloodyshine.app.R
import java.util.Locale
import android.provider.Settings

class DisconnectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_disconnect)

        val title = intent.getStringExtra("title") ?: getString(R.string.api_disconnect_unknown_title)
        val desc = intent.getStringExtra("desc") ?: getString(R.string.api_disconnect_unknown_desc)
        val downloadUrl = intent.getStringExtra("download_url")

        val tvTitle: TextView = findViewById(R.id.tvDisconnectTitle)
        val tvDesc: TextView = findViewById(R.id.tvDisconnectDesc)
        val btnAction: Button = findViewById(R.id.btnDisconnectAction)

        tvTitle.text = title
        tvDesc.text = desc

        if (downloadUrl != null) {
            btnAction.text = getString(R.string.api_button_download)
            btnAction.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl))
                startActivity(intent)
            }
        } else {
            btnAction.text = getString(R.string.api_button_close)
            btnAction.setOnClickListener {
                finish()
            }
        }

        // Hidden debug: long-click title to copy UID
        tvTitle.setOnLongClickListener {
            val uid = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ANDROID_ID
            )
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("UID", uid))
            Toast.makeText(this, getString(R.string.uid_copy), Toast.LENGTH_SHORT).show()
            true
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Intentionally do nothing — user must tap button
    }
}
