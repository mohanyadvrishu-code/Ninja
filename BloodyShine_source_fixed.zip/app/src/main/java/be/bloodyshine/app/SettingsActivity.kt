package be.bloodyshine.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var switchGlow: Switch
    private lateinit var langEn: RadioButton
    private lateinit var langRu: RadioButton
    private lateinit var btnClose: ImageButton
    private lateinit var titleLayout: ConstraintLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences("bloodyshine_prefs", MODE_PRIVATE)

        switchGlow = findViewById(R.id.switchGlow)
        langEn = findViewById(R.id.langEn)
        langRu = findViewById(R.id.langRu)
        btnClose = findViewById(R.id.btnClose)
        titleLayout = findViewById(R.id.titleLayout)

        // Restore saved state
        switchGlow.isChecked = prefs.getBoolean("glow_enabled", true)
        val currentLang = prefs.getString("language", "en") ?: "en"
        if (currentLang == "ru") {
            langRu.isChecked = true
            langEn.isChecked = false
        } else {
            langEn.isChecked = true
            langRu.isChecked = false
        }

        switchGlow.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("glow_enabled", isChecked).apply()
            MainActivity.glowLayout?.visibility = if (isChecked) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }
        }

        langEn.setOnClickListener {
            prefs.edit().putString("language", "en").apply()
            applyLocale("en")
        }

        langRu.setOnClickListener {
            prefs.edit().putString("language", "ru").apply()
            applyLocale("ru")
        }

        btnClose.setOnClickListener {
            finish()
            overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
            )
        }

        // Hidden debug: long-click title to copy UID
        titleLayout.setOnLongClickListener {
            val uid = android.provider.Settings.Secure.getString(
                contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            )
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("UID", uid))
            Toast.makeText(this, getString(R.string.uid_copy), Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun applyLocale(lang: String) {
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = resources.configuration
        config.setLocale(locale)
        @Suppress("DEPRECATION")
        resources.updateConfiguration(config, resources.displayMetrics)
    }
}
