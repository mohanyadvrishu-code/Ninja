package be.bloodyshine.bedrockapi

import io.netty.bootstrap.Bootstrap
import io.netty.buffer.ByteBuf
import io.netty.buffer.Unpooled
import io.netty.channel.*
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.DatagramChannel
import io.netty.channel.socket.DatagramPacket
import io.netty.channel.socket.nio.NioDatagramChannel
import java.net.InetSocketAddress
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

data class BedrockPong(
    val motd: String,
    val protocol: Int,
    val version: String,
    val playerCount: Int,
    val maxPlayers: Int,
    val serverGuid: Long,
    val subMotd: String,
    val gameMode: String
)

class PingClient {

    companion object {
        private const val UNCONNECTED_PING_ID: Byte = 0x01
        private const val UNCONNECTED_PONG_ID: Byte = 0x1C

        // RakNet MAGIC: 00 ff ff 00 fe fe fe fe fd fd fd fd 12 34 56 78
        private val MAGIC = byteArrayOf(
            0x00.toByte(), 0xff.toByte(), 0xff.toByte(), 0x00.toByte(),
            0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(),
            0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(),
            0x12.toByte(), 0x34.toByte(), 0x56.toByte(), 0x78.toByte()
        )
    }

    fun ping(address: InetSocketAddress, timeout: Long = 5000): BedrockPong? {
        val result = arrayOfNulls<BedrockPong>(1)
        val latch = CountDownLatch(1)
        val group = NioEventLoopGroup(1)

        try {
            val bootstrap = Bootstrap()
                .group(group)
                .channel(NioDatagramChannel::class.java)
                .option(ChannelOption.SO_BROADCAST, true)
                .handler(object : SimpleChannelInboundHandler<DatagramPacket>() {
                    override fun channelRead0(ctx: ChannelHandlerContext, msg: DatagramPacket) {
                        val buf = msg.content()
                        val id = buf.readByte()
                        if (id == UNCONNECTED_PONG_ID) {
                            buf.readLong()  // timestamp
                            buf.readLong()  // server GUID
                            buf.skipBytes(16) // magic
                            val strLen = buf.readShort().toInt()
                            val bytes = ByteArray(strLen)
                            buf.readBytes(bytes)
                            val pongStr = String(bytes, Charsets.UTF_8)
                            result[0] = parsePong(pongStr)
                            latch.countDown()
                        }
                    }

                    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
                        latch.countDown()
                    }
                })

            val channel = bootstrap.bind(0).syncUninterruptibly().channel()

            // Build UnconnectedPing packet
            val buf: ByteBuf = Unpooled.buffer()
            buf.writeByte(UNCONNECTED_PING_ID.toInt())
            buf.writeLong(System.currentTimeMillis())
            buf.writeBytes(MAGIC)
            buf.writeLong(0L) // client GUID

            channel.writeAndFlush(DatagramPacket(buf, address))
            latch.await(timeout, TimeUnit.MILLISECONDS)
            channel.close()
        } finally {
            group.shutdownGracefully(0, 0, TimeUnit.MILLISECONDS)
        }

        return result[0]
    }

    private fun parsePong(pong: String): BedrockPong? {
        // Format: "MCPE;{motd};{protocol};{version};{players};{maxPlayers};{serverGuid};{subMotd};{gameMode}"
        val parts = pong.split(";")
        if (parts.size < 6) return null
        return try {
            BedrockPong(
                motd = parts.getOrElse(1) { "" },
                protocol = parts.getOrElse(2) { "0" }.toIntOrNull() ?: 0,
                version = parts.getOrElse(3) { "" },
                playerCount = parts.getOrElse(4) { "0" }.toIntOrNull() ?: 0,
                maxPlayers = parts.getOrElse(5) { "0" }.toIntOrNull() ?: 0,
                serverGuid = parts.getOrElse(6) { "0" }.toLongOrNull() ?: 0L,
                subMotd = parts.getOrElse(7) { "" },
                gameMode = parts.getOrElse(8) { "" }
            )
        } catch (e: Exception) {
            null
        }
    }
}
